# Changes in this update

- Added Section 4.3 with a precise definition of empirical feasibility.
- Added Figure 1: three alpha panels, each with curves for K = 2, 4, 16.
- Regenerated feasibility summaries from the existing 54,000 records.
- Independently checked 118 feasibility classifications; all matched.
- Added Section 4.4 and Table 3 for the Fan et al. population comparison.
- Recomputed all nine comparison rows for alpha = 0.2, 0.5, 0.8.
- Added independent rearrangement and alternative-LP checks.
- Explicitly introduced the acronym LP in the experiment setup.
- Retained the shorter Section 4.1, all Section 4.2 RMSEs, and the explicit
  n = N in {250, 1,000, 4,000, 16,000} grid.
- No exponent estimation and no new Monte Carlo replications in this update.
- The PDF is a compiled experiment-section excerpt, not the full paper.
