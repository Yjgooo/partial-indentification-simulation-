#!/usr/bin/env python3
"""Reproducible endpoint-accuracy experiment for the revised Section 4.2.

Implements the current manuscript's Algorithm 1, in its mean-outcome
parameterization: unnormalized L1 violations, D=[-1,3]^(6K), exact optimal-face
max/min ATE tie-breaking. Uses empirical frequencies WITHOUT pseudocounts.
Independent primary and auxiliary multinomial samples; no failed replication
is silently dropped. Each input setting/replication has a deterministic seed.
"""
from __future__ import annotations
import os
for _k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[_k] = '1'
import argparse
from concurrent.futures import ProcessPoolExecutor
import json
import math
from pathlib import Path
import platform
import sys
import time
import warnings

import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog, OptimizeWarning
from scipy.sparse import csc_matrix, hstack, eye, vstack
from population_bounds import dgp, mean_bounds, success_mass_bounds

# HiGHS receives the thread option through SciPy. Restrict each worker to one.
warnings.filterwarnings('ignore', category=OptimizeWarning,
                        message='Unrecognized options detected.*')
OPTIONS = dict(primal_feasibility_tolerance=1e-9,
               dual_feasibility_tolerance=1e-9, threads=1)
RHO = 0.10
BASE_SEED = 202611090042
SIZES = (250, 1000, 4000, 16000)
KS = (2, 4, 16)
ALPHAS = (0.2, 0.5, 0.8)


def penalty_level(n: int) -> float:
    return 5.0*math.log(math.log(n))/math.log(math.log(30000.0))


def linear_system(pa: np.ndarray, r: np.ndarray, g: np.ndarray,
                  proxy: np.ndarray, rho: float = RHO):
    """Return p, M, b for min p'x s.t. Mx>=b (paper Eq. 4).

    x=(m0,t00,t01,m1,t10,t11), each block length K.
    Only D=[-1,3]^d is a hard constraint in the penalized problems.
    """
    K = g.shape[1]
    nv = 6*K
    px = pa @ g
    objective = np.zeros(nv)
    objective[:K] = -px
    objective[3*K:4*K] = px
    rows, rhs = [], []
    for a in range(2):
        ms = 3*a*K
        for k in range(K):
            row = np.zeros(nv); row[ms+k] = 1
            rows.extend([row, -row]); rhs.extend([0.0,-1.0])
        row = np.zeros(nv); row[ms:ms+K] = g[a]
        rows.extend([row, -row]); rhs.extend([r[a,1],-r[a,1]])
        for y in range(2):
            ts = ms+(1+y)*K
            for k in range(K):
                # q_candidate = intercept+slope*m
                slope = (1 if y else -1)*g[a,k]/r[a,y]
                intercept = 0 if y else g[a,k]/r[a,y]
                row = np.zeros(nv); row[ts+k] = 1; row[ms+k] = -slope
                rows.append(row); rhs.append(intercept-proxy[a,y,k])
                row = np.zeros(nv); row[ts+k] = 1; row[ms+k] = slope
                rows.append(row); rhs.append(proxy[a,y,k]-intercept)
            row = np.zeros(nv); row[ts:ts+K] = -1
            rows.append(row); rhs.append(-2*rho)
    return objective, csc_matrix(np.asarray(rows)), np.asarray(rhs)


def checked_linprog(c, A_ub, b_ub, bounds, A_eq=None, b_eq=None):
    out = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                  bounds=bounds, method='highs-ds', options=OPTIONS)
    if not out.success and out.status != 2:
        out = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                      bounds=bounds, method='highs-ds',
                      options={**OPTIONS, 'presolve':False})
    return out


def penalty_endpoint(p, M, b, w: float, sign: int):
    """Minimize sign*p'x+w*sum(slack), then maximize sign*p'x on argmin."""
    nr, nx = M.shape
    cc = np.r_[sign*p, np.full(nr,w)]
    A = hstack([-M, -eye(nr,format='csc')],format='csc')
    bounds = [(-1.,3.)]*nx+[(0.,None)]*nr
    first = checked_linprog(cc,A,-b,bounds)
    if not first.success:
        raise RuntimeError('penalty stage 1: '+first.message)
    secondary = np.r_[-sign*p, np.zeros(nr)]
    face = csc_matrix(cc[None,:])
    second = checked_linprog(secondary,A,-b,bounds,face,np.array([first.fun]))
    fallback = False
    if not second.success:
        # No relaxed statistical constraints: tolerance only on optimal-face value.
        second = checked_linprog(secondary, vstack([A,face,-face],format='csc'),
                                 np.r_[-b,first.fun+1e-9,-first.fun+1e-9],bounds)
        fallback = True
    if not second.success:
        raise RuntimeError('penalty stage 2: '+second.message)
    xx = second.x[:nx]
    violation = np.maximum(b-M@xx,0)
    gap = abs(float(cc@second.x-first.fun))
    resid = max(float(np.maximum(A@second.x+b,0).max(initial=0)),
                float(np.maximum(-1-xx,0).max(initial=0)),
                float(np.maximum(xx-3,0).max(initial=0)),
                float(np.maximum(-second.x[nx:],0).max(initial=0)))
    direct_objective_gap = abs(float(sign*(p@xx)+w*violation.sum()-first.fun))
    if max(gap,resid,direct_objective_gap) > 2e-7:
        raise RuntimeError(f'solver validation failure: {gap=}, {resid=}, {direct_objective_gap=}')
    return dict(value=float(p@xx), first_ate=float(p@first.x[:nx]),
                violation=float(violation.sum()), optimal_face_gap=gap,
                residual=resid, objective_gap=direct_objective_gap,
                face_fallback=fallback)


def raw_endpoint(p,M,b,sign=1):
    out=checked_linprog(sign*p,-M,-b,[(-1.,3.)]*len(p))
    if out.status==2: return False, float('nan')
    if not out.success: raise RuntimeError('direct LP: '+out.message)
    return True,float(p@out.x)


def estimate_inputs(main,aux):
    ay = main.sum(axis=2)
    a_main = ay.sum(axis=1)
    a_aux = aux.sum(axis=1)
    if min(ay.min(),a_aux.min())<=0:
        raise RuntimeError('empty treatment/outcome stratum; no smoothing or deletion applied')
    pa = a_main/main.sum()
    r = ay/a_main[:,None]
    proxy = main/ay[:,:,None]
    g = aux/a_aux[:,None]
    return pa,r,g,proxy


def prepare_oracles():
    oracles,exactness,inputs = [],[],{}
    for K in KS:
        d = dgp(K)
        for alpha in ALPHAS:
            proxy = d['q']+alpha*RHO*d['v'][None,None,:]
            assert proxy.min()>0
            np.testing.assert_allclose(proxy.sum(2),1,atol=1e-14)
            oracle,_ = mean_bounds(d,proxy,RHO,label=f'K{K}_a{alpha}')
            alternative=success_mass_bounds(d,proxy,RHO,label=f'crosscheck_K{K}_a{alpha}')
            np.testing.assert_allclose(oracle,alternative,atol=1e-8,rtol=0)
            pp,M,b=linear_system(d['pa'],d['r'],d['g'],proxy)
            direct = np.array([raw_endpoint(pp,M,b,s)[1] for s in (1,-1)])
            np.testing.assert_allclose(direct,oracle,atol=1e-8,rtol=0)
            for n in SIZES:
                psol=[penalty_endpoint(pp,M,b,penalty_level(n),s) for s in (1,-1)]
                err=float(np.max(np.abs(np.array([o['value'] for o in psol])-oracle)))
                exactness.append(dict(K=K,alpha=alpha,n=n,w=penalty_level(n),
                                      max_abs_population_error=err))
                if err>1e-7:raise RuntimeError('Population exactness failed')
            mainlaw = d['pa'][:,None,None]*d['r'][:,:,None]*proxy
            auxlaw = d['pa'][:,None]*d['g']
            np.testing.assert_allclose(mainlaw.sum(),1,atol=1e-14)
            np.testing.assert_allclose(auxlaw.sum(),1,atol=1e-14)
            key=(K,alpha)
            inputs[key]=(mainlaw,auxlaw,oracle)
            oracles.append(dict(K=K,alpha=alpha,rho=RHO,true_ate=d['true_ate'],
                                lower=oracle[0],upper=oracle[1],width=oracle[1]-oracle[0]))
    return pd.DataFrame(oracles),pd.DataFrame(exactness),inputs


def simulate_batch(payload):
    K,alpha,n,start,stop,mainlaw,auxlaw,oracle,seed=payload
    out=[]
    for rep in range(start,stop):
        base=dict(K=K,alpha=alpha,n=n,N=n,replication=rep)
        try:
            ss=np.random.SeedSequence([seed,K,int(round(alpha*100)),n,rep])
            seq1,seq0=ss.spawn(2)
            primary=np.random.default_rng(seq1).multinomial(n,mainlaw.ravel()).reshape(2,2,K)
            auxiliary=np.random.default_rng(seq0).multinomial(n,auxlaw.ravel()).reshape(2,K)
            pa,r,g,proxy=estimate_inputs(primary,auxiliary)
            p,M,b=linear_system(pa,r,g,proxy)
            low=penalty_endpoint(p,M,b,penalty_level(n),1)
            up=penalty_endpoint(p,M,b,penalty_level(n),-1)
            feasible,rawlo=raw_endpoint(p,M,b)
            loerr=low['value']-oracle[0]; uperr=up['value']-oracle[1]
            out.append({**base,'success':True,'error':'',
                'lower_hat':low['value'],'upper_hat':up['value'],
                'lower_oracle':oracle[0],'upper_oracle':oracle[1],
                'lower_error':loerr,'upper_error':uperr,
                'ordered':low['value']<=up['value']+1e-8,
                'raw_feasible':feasible,'raw_lower':rawlo,
                'lower_violation':low['violation'],'upper_violation':up['violation'],
                'max_face_gap':max(low['optimal_face_gap'],up['optimal_face_gap']),
                'max_solver_residual':max(low['residual'],up['residual']),
                'max_objective_gap':max(low['objective_gap'],up['objective_gap']),
                'face_fallback':low['face_fallback'] or up['face_fallback'],
                'zero_aux_cells':int((auxiliary==0).sum()),
                'zero_main_cells':int((primary==0).sum())})
        except Exception as exc:
            out.append({**base,'success':False,'error':str(exc)})
    return out


def summarize(frame):
    rows=[]
    for (K,alpha,n),cell in frame.groupby(['K','alpha','n']):
        if not cell.success.all():
            raise RuntimeError(f'Failure in {K=},{alpha=},{n=}: '+str(cell.loc[~cell.success,'error'].tolist()[:3]))
        sqlo=cell.lower_error.to_numpy()**2; squp=cell.upper_error.to_numpy()**2
        lr=np.sqrt(sqlo.mean()); ur=np.sqrt(squp.mean())
        rows.append(dict(K=K,alpha=alpha,n=n,N=n,repetitions=len(cell),
                         lower_oracle=float(cell.lower_oracle.iloc[0]),upper_oracle=float(cell.upper_oracle.iloc[0]),
                         lower_rmse=lr,upper_rmse=ur,
                         lower_rmse_mcse=sqlo.std(ddof=1)/(2*lr*np.sqrt(len(cell))),
                         upper_rmse_mcse=squp.std(ddof=1)/(2*ur*np.sqrt(len(cell))),
                         lower_bias=cell.lower_error.mean(),upper_bias=cell.upper_error.mean(),
                         mean_lower=cell.lower_hat.mean(),mean_upper=cell.upper_hat.mean(),
                         raw_feasibility_rate=cell.raw_feasible.mean(),ordered_rate=cell.ordered.mean(),
                         zero_aux_cell_rate=(cell.zero_aux_cells>0).mean(),
                         mean_lower_violation=cell.lower_violation.mean(),mean_upper_violation=cell.upper_violation.mean(),
                         max_face_gap=cell.max_face_gap.max(),
                         max_solver_residual=cell.max_solver_residual.max(),
                         max_objective_gap=cell.max_objective_gap.max(),
                         fallback_count=cell.face_fallback.sum()))
    return pd.DataFrame(rows)


def run(args):
    t=time.time();args.output.mkdir(parents=True,exist_ok=True)
    oracle,exactness,inputs=prepare_oracles()
    oracle.to_csv(args.output/'population_oracles.csv',index=False)
    exactness.to_csv(args.output/'population_exactness.csv',index=False)
    print('Population LP cross-checks and exactness checks passed.',flush=True)
    jobs=[]
    for (K,alpha),(main,aux,ob) in inputs.items():
        for n in SIZES:
            for i in range(0,args.repetitions,args.batch_size):
                jobs.append((K,alpha,n,i,min(i+args.batch_size,args.repetitions),main,aux,ob,args.seed))
    rows=[]
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        for j,batch in enumerate(executor.map(simulate_batch,jobs),1):
            rows.extend(batch)
            if j%max(1,math.ceil(args.repetitions/args.batch_size))==0:
                cell=batch[0]
                print(f"K={cell['K']} alpha={cell['alpha']} n={cell['n']}: {len(rows)}/{len(jobs)*args.batch_size} rows; elapsed={time.time()-t:.1f}s",flush=True)
                pd.DataFrame(rows).to_csv(args.output/'replications_partial.csv.gz',index=False,compression='gzip')
    frame=pd.DataFrame(rows).sort_values(['K','alpha','n','replication'])
    frame.to_csv(args.output/'replications.csv.gz',index=False,compression='gzip')
    summary=summarize(frame)
    summary.to_csv(args.output/'accuracy_summary.csv',index=False)
    metadata=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),
                  support_sizes=KS,alpha_values=ALPHAS,sample_sizes=SIZES,rho=RHO,
                  repetitions_per_setting=args.repetitions,total_replications=len(frame),seed=args.seed,
                  probability_estimation='Empirical frequencies; no pseudocounts',
                  penalty='Unnormalized rows of Theorem 2, D=[-1,3]^(6K), max/min ATE optimal-face selection',
                  penalty_rule='5*log(log(min(n,N)))/log(log(30000))',workers=args.workers,
                  elapsed_seconds=time.time()-t)
    (args.output/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    checks=dict(all_successful=bool(frame.success.all()),
                all_ordered=bool(frame.ordered.all()),
                max_population_exactness_error=float(exactness.max_abs_population_error.max()),
                max_optimal_face_gap=float(frame.max_face_gap.max()),
                max_solver_residual=float(frame.max_solver_residual.max()),
                max_objective_gap=float(frame.max_objective_gap.max()),
                face_fallbacks=int(frame.face_fallback.sum()),
                no_exponent_estimation=True)
    (args.output/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    (args.output/'replications_partial.csv.gz').unlink(missing_ok=True)
    print(summary[['K','alpha','n','lower_rmse','upper_rmse','raw_feasibility_rate','ordered_rate']].to_string(index=False),flush=True)
    print(json.dumps(checks,indent=2),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('results'))
    parser.add_argument('--repetitions',type=int,default=1500)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--batch-size',type=int,default=50)
    parser.add_argument('--seed',type=int,default=BASE_SEED)
    run(parser.parse_args())
