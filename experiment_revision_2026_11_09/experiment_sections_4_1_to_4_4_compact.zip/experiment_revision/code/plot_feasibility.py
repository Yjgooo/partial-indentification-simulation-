#!/usr/bin/env python3
"""Create one separate feasibility plot per alpha; LaTeX arranges the panels."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def plot(root: Path) -> None:
    data=pd.read_csv(root/'results/feasibility_summary.csv')
    dest=root/'manuscript/figures'
    dest.mkdir(parents=True,exist_ok=True)
    for alpha in (0.2,0.5,0.8):
        fig,ax=plt.subplots(figsize=(3.8,3.15))
        for K,marker,ls in ((2,'o','-'),(4,'s','--'),(16,'^',':')):
            rows=data[(data.alpha==alpha)&(data.K==K)].sort_values('n')
            if len(rows)!=4:raise ValueError(f'Expected four sample sizes for {K=}, {alpha=}')
            ax.plot(rows.n,rows.feasibility_percent,marker=marker,linestyle=ls,
                    linewidth=1.8,markersize=5,label=f'$K={K}$')
        ax.set_xscale('log',base=4)
        ax.set_xticks([250,1000,4000,16000],['250','1,000','4,000','16,000'],rotation=30,ha='right')
        ax.set_yticks([0,25,50,75,100]); ax.set_ylim(-3,103)
        ax.set_title(rf'$\alpha={alpha}$',fontsize=15)
        ax.set_xlabel(r'Sample size, $n=N$',fontsize=12)
        ax.set_ylabel('Feasible replications (%)',fontsize=12)
        ax.tick_params(labelsize=11)
        ax.grid(axis='y',alpha=.25)
        ax.legend(loc='lower right',fontsize=10,frameon=False)
        fig.tight_layout(pad=.5)
        stem='feasibility_alpha_'+str(alpha).replace('.','')
        fig.savefig(dest/(stem+'.pdf'))
        fig.savefig(dest/(stem+'.png'),dpi=240)
        plt.close(fig)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    plot(p.parse_args().root)
