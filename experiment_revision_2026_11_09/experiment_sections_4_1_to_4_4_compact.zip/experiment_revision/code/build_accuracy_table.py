#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
df=pd.read_csv(ROOT/'results/accuracy_summary.csv')
lines=[r'\begin{table}[htbp]',r'\centering',
 r'\caption{RMSE of the estimated population interval endpoints.}',
 r'\label{tab:endpoint-rmse}',r'\small',r'\setlength{\tabcolsep}{8pt}',
 r'\begin{tabular}{@{}r rr rr rr@{}}',r'\toprule',
 r'& \multicolumn{2}{c}{$K=2$} & \multicolumn{2}{c}{$K=4$}',
 r'& \multicolumn{2}{c}{$K=16$} \\',
 r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}',
 r'$n=N$ & Lower & Upper & Lower & Upper & Lower & Upper \\',r'\midrule']
for i,alpha in enumerate((0.2,0.5,0.8)):
 if i:lines.append(r'\addlinespace[4pt]')
 lines.append(r'\multicolumn{7}{l}{$\alpha='+str(alpha)+r'$} \\')
 for n in (250,1000,4000,16000):
  cells=[]
  for K in (2,4,16):
   row=df[(df.K==K)&(df.alpha==alpha)&(df.n==n)].iloc[0]
   assert row.repetitions==1500
   cells.extend([f'{row.lower_rmse:.4f}',f'{row.upper_rmse:.4f}'])
  nstr=f'{n:,}'.replace(',',r'{,}')
  lines.append('$'+nstr+'$ & '+' & '.join(cells)+r' \\')
lines.extend([r'\bottomrule',r'\end{tabular}',r'\par\smallskip',
 r'\begin{minipage}{\linewidth}',r'\footnotesize',
 r'Each entry uses all $1{,}500$ replications and the fixed assumed TV radius',
 r'$\rho=0.10$. Errors are measured relative to the appropriate lower or',
 r'upper population bound, which depends on $(K,\alpha)$.',
 r'\end{minipage}',r'\end{table}'])
(ROOT/'manuscript/table_section42.tex').write_text('\n'.join(lines)+'\n')
# Also provide a simple CSV in table order.
rows=[]
for alpha in (0.2,0.5,0.8):
 for n in (250,1000,4000,16000):
  row={'alpha':alpha,'n=N':n}
  for K in (2,4,16):
   d=df[(df.K==K)&(df.alpha==alpha)&(df.n==n)].iloc[0]
   row[f'K{K}_lower_RMSE']=d.lower_rmse;row[f'K{K}_upper_RMSE']=d.upper_rmse
  rows.append(row)
pd.DataFrame(rows).to_csv(ROOT/'results/table42_RMSE.csv',index=False)
