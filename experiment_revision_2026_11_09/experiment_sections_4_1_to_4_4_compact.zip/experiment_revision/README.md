# Experiment-section revision: Sections 4.1–4.4

## Deliverable scope

This is the updated experiment-section replacement package, not a modified
copy of the original full-paper source archive. The compiled PDF contains
Section 4 (setup), Sections 4.1–4.4, and the reference for the new comparison.
The full original paper is not included or compiled. This revision extends
the previously delivered replacement package.

The setup retains K = 2, 4, 16; alpha = 0.2, 0.5, 0.8; the fixed assumed
TV radius rho = 0.10; and the explicit sample-size list
n = N in {250, 1,000, 4,000, 16,000}. No larger sample sizes or exponent
estimation are included in the main experiment text.

## What is new

- **Section 4.3 (Empirical feasibility):** a direct definition of the
  percentage of sample pairs with nonempty plug-in constraints; one figure
  with three alpha panels; a concise account of the effects of sample size,
  support size, and contamination level. The text distinguishes allowing
  violations in the penalized estimator from satisfying the original LP.
- **Section 4.4 (Comparison with Fan et al. (2014)):** nine freshly computed
  population comparisons for K = 2, 4, 16 and alpha = 0.2, 0.5, 0.8. Both
  methods have auxiliary information. Only the proposed method adds the
  proxy distribution and the four TV restrictions. This is deliberately
  distinct from Section 4.1's with-versus-without-auxiliary comparison.
- **Section 4.1 and Section 4.2:** retained from the approved replacement
  package. The setup now explicitly introduces “linear program (LP).”

## Simulation provenance

The feasibility figure uses the same 54,000 replication records already
used for Section 4.2. No new Monte Carlo replications were run in this update,
and no original replication records or accuracy estimates were changed.
The saved results contain 1,500 observations in each of 36 settings.
All percentages were rebuilt from the individual records and agree with
the previously saved summary. All 54,000 penalized solutions are successful
and ordered, as recorded in those results.

We additionally reconstructed 118 samples with the original seeds and
checked feasibility using an independent success-mass LP parameterization.
Every classification agreed. The check starts with an interior-point solver;
rare unresolved solver statuses are retried without presolve, then with
simplex if needed. Each solver attempt is recorded in
`results/feasibility_independent_checks.csv`. A solver error is never counted
as infeasibility.

The estimator used in the retained simulations is unchanged: empirical
frequencies without pseudocounts, mean-outcome parameters, unnormalized
L1 violation penalty, domain [-1,3]^(6K), and the stated optimal-face
selection. Its implementation paragraph is `manuscript/estimation_details.tex`.
Do not retain the old pseudocount/normalized-epigraph appendix description
when these results are integrated into the full paper.

## Population comparison and validation

Fan et al.'s finite-support, binary-outcome problem uses the marginal
compatibility constraints, but no proxy-TV restrictions. The proposed
problem adds all four TV restrictions. Both are continuous LPs, not grid
approximations. No branch-and-bound, branch-and-cut, or nonlinear optimizer
is used for this comparison. The grid-only Section 4.1 is unchanged.

Fan's LP endpoints were checked against a separate sorted-mass
(rearrangement) calculation. Proposed endpoints were checked against a
success-mass LP parameterization. Additional checks include containment of
the true ATE, nesting in Fan's interval, agreement with the Section 4.2
population endpoints, recovery of Fan's interval at radius 1, and recovery
of the truth at radius 0 with an unperturbed proxy. Numerical results and
witnesses are included in `results/fan_*` and `results/sections43_44_checks.json`.
The observed width reductions are 68.8343%–94.4444%; they reflect additional
information and restrictions, not better numerical optimization.

Reference:
Yanqin Fan, Robert Sherman, and Matthew Shum (2014), “Identifying Treatment
Effects Under Data Combination,” Econometrica 82(2):811–822,
doi:10.3982/ECTA10601, Theorem 3.2(i) and Eq. (3.1).
Author-hosted paper: https://www.its.caltech.edu/~mshum/papers/FSS.pdf
The cited theorem and equation were checked against the rendered original.
The source paper itself is not redistributed in this package.

## Reproduce the new additions

From the package root, with NumPy, pandas, SciPy, and Matplotlib installed:

```bash
python code/build_feasibility_fan.py
python code/plot_feasibility.py
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error experiment_preview.tex
pdflatex -interaction=nonstopmode -halt-on-error experiment_preview.tex
```

These commands reuse `results/replications.csv.gz`; they do not repeat the
Monte Carlo experiment. They recreate the new numerical comparisons, checks,
table, plots, and complete experiment-section preview.

To reproduce the earlier sampling experiment from scratch, use the retained
`code/run_accuracy.py` and `code/validate_accuracy.py`. Run into a separate
output directory to preserve the delivered records. The metadata file lists
the original random seed and numerical environment.

## Manuscript integration

`manuscript/experiment_preview.tex` is a standalone compilation wrapper,
not the original conference template. Replace the old experiment setup and
subsections with `experiment_setup.tex` and `section_4_1.tex` through
`section_4_4.tex`, with their table/figure inputs. Use the full manuscript's
normal bibliography rather than the preview's compact reference list.
The new citation key is `fan2014identifying`; reconcile it with the existing
Fan entry instead of duplicating that reference.

The older `apply_to_manuscript.py` is not included in this update because
it would preserve the obsolete Section 4.3. The replacement source files
are authoritative. Recompile the full paper after integration. Old
simulation appendix paragraphs, Design 1/Design 2 figures, and rate tables
must not be presented as results of this revised experiment.
