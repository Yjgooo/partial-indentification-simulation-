#!/usr/bin/env python3
"""Independent formulation check of the penalized endpoints.

Eliminate the paper's bounded TV auxiliary variables analytically. For fixed m,
the minimized violation sum is the sum of box violations, absolute margin
errors, and positive excesses of the four L1 distances above 2*rho. Encode
that convex piecewise-linear function directly, and independently check the
max/min tie-breaking. These checks validate estimators, not just sharp bounds.
"""
from __future__ import annotations
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy.sparse import csc_matrix
from run_accuracy import (dgp, RHO, SIZES, KS, ALPHAS, BASE_SEED,
    linear_system, penalty_endpoint, estimate_inputs, penalty_level, checked_linprog)


def alternative(pa,r,g,proxy,w,sign):
    K=g.shape[1]; nm=2*K
    # x=(m:2K, absdiff:4K, lower_violation:2K, upper_violation:2K,
    #    margin_violation:2, tv_excess:4).
    nvar=10*K+6
    ds=2*K; ls=6*K; us=8*K; es=10*K; ts=10*K+2
    c=np.zeros(nvar); p=np.r_[-(pa@g),pa@g]
    c[:nm]=sign*p
    c[ls:]=w
    rows=[];rhs=[]
    for a in range(2):
        ms=a*K
        for k in range(K):
            row=np.zeros(nvar);row[ms+k]=-1;row[ls+ms+k]=-1
            rows.append(row);rhs.append(0.)
            row=np.zeros(nvar);row[ms+k]=1;row[us+ms+k]=-1
            rows.append(row);rhs.append(1.)
        for s in (-1,1):
            row=np.zeros(nvar);row[ms:ms+K]=s*g[a];row[es+a]=-1
            rows.append(row);rhs.append(s*r[a,1])
        for y in range(2):
            start=ds+(2*a+y)*K
            for k in range(K):
                slope=(1 if y else -1)*g[a,k]/r[a,y]
                intercept=0 if y else g[a,k]/r[a,y]
                for s in (-1,1):
                    row=np.zeros(nvar);row[ms+k]=s*slope;row[start+k]=-1
                    rows.append(row);rhs.append(s*(proxy[a,y,k]-intercept))
            row=np.zeros(nvar);row[start:start+K]=1;row[ts+2*a+y]=-1
            rows.append(row);rhs.append(2*RHO)
    A=csc_matrix(np.array(rows));b=np.array(rhs)
    bounds=[(-1,3)]*nm+[(0,None)]*(nvar-nm)
    st1=checked_linprog(c,A,b,bounds)
    if not st1.success:raise RuntimeError(st1.message)
    second_c=np.zeros(nvar);second_c[:nm]=-sign*p
    st2=checked_linprog(second_c,A,b,bounds,csc_matrix(c[None,:]),np.array([st1.fun]))
    if not st2.success:raise RuntimeError(st2.message)
    return float(p@st2.x[:nm]),float(st1.fun)


def run(output):
    records=[]
    for K in KS:
        d=dgp(K)
        for alpha in ALPHAS:
            proxy=d['q']+alpha*RHO*d['v'][None,None,:]
            primary=d['pa'][:,None,None]*d['r'][:,:,None]*proxy
            aux=d['pa'][:,None]*d['g']
            for n in SIZES:
                # independent seeds; includes random and rare-cell regimes
                for rep in range(3):
                    rng=np.random.default_rng(np.random.SeedSequence([BASE_SEED+1,K,int(alpha*100),n,rep]))
                    ca=rng.multinomial(n,primary.ravel()).reshape(2,2,K)
                    cb=rng.multinomial(n,aux.ravel()).reshape(2,K)
                    pa,r,g,pr=estimate_inputs(ca,cb)
                    p,M,b=linear_system(pa,r,g,pr)
                    for sign in (1,-1):
                        ours=penalty_endpoint(p,M,b,penalty_level(n),sign)
                        theirs,_=alternative(pa,r,g,pr,penalty_level(n),sign)
                        diff=abs(ours['value']-theirs)
                        records.append(dict(K=K,alpha=alpha,n=n,rep=rep,sign=sign,difference=diff))
                        if diff>1e-7:raise RuntimeError(str(records[-1]))
    frame=pd.DataFrame(records)
    frame.to_csv(output/'independent_estimator_checks.csv',index=False)
    check=dict(passed=True,number_of_endpoint_checks=len(frame),max_difference=float(frame.difference.max()))
    (output/'independent_estimator_checks.json').write_text(json.dumps(check,indent=2)+'\n')
    print(check)
if __name__=='__main__':
    run(Path(sys.argv[1]))
