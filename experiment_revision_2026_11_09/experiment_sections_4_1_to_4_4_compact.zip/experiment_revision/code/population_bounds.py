#!/usr/bin/env python3
"""Population ATE bounds: Fan--Sherman--Shum (2014) versus proxy-TV bounds.

Reproduce:
    python run_comparison.py --output results
Requires Python 3.10+, numpy, scipy, pandas.

No sampling, smoothing, penalty tuning, or parametric candidate regressions.
The linear DGP generates population inputs only. All candidate outcome means
are free cellwise subject to their marginal and, when applicable, TV constraints.
"""
from __future__ import annotations

import argparse
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog

TOL = 2e-8
AUDIT: list[dict] = []


def dgp(K: int) -> dict[str, np.ndarray | float | int]:
    if K < 2 or K % 2:
        raise ValueError('K must be an even integer >= 2.')
    x = (np.arange(1, K + 1) - (K + 1)/2) / np.sqrt((K*K - 1)/12)
    px = np.full(K, 1/K)
    e = 0.5 + 0.1*x
    m = 0.35 + 0.15*x[None, :] + 0.08*np.arange(2)[:, None]
    ax = px[None, :]*np.stack([1-e, e])  # joint P(A,X)
    pa = ax.sum(axis=1)
    g = ax / pa[:, None]  # P(X|A)
    r1 = (g*m).sum(axis=1)
    r = np.stack([1-r1, r1], axis=1)  # P(Y=y|A=a)
    q = np.stack([g*(1-m), g*m], axis=1) / r[:, :, None]
    v = (2/K)*np.r_[np.ones(K//2), -np.ones(K//2)]
    np.testing.assert_allclose(px @ x, 0, atol=1e-14)
    np.testing.assert_allclose(px @ (x*x), 1, atol=1e-14)
    np.testing.assert_allclose(r1, [0.32, 0.46], atol=1e-14)
    np.testing.assert_allclose(q.sum(axis=2), 1, atol=1e-14)
    assert 0 < e.min() <= e.max() < 1
    assert 0 < m.min() <= m.max() < 1
    return dict(K=K, x=x, px=px, pa=pa, g=g, r=r, q=q, v=v,
                true_m=m, true_ate=float(px @ (m[1]-m[0])))


def solve_checked(c, Aeq, beq, Aub, bub, bounds, label, method='highs-ds'):
    c, Aeq, beq = np.asarray(c), np.asarray(Aeq), np.asarray(beq)
    Aub = None if Aub is None else np.asarray(Aub)
    bub = None if bub is None else np.asarray(bub)
    sol = linprog(c, A_ub=Aub, b_ub=bub, A_eq=Aeq, b_eq=beq,
                  bounds=bounds, method=method,
                  options={'threads': 1, 'primal_feasibility_tolerance': 1e-9,
                           'dual_feasibility_tolerance': 1e-9,
                           'ipm_optimality_tolerance': 1e-10})
    if not sol.success:
        raise RuntimeError(f'{label}: {sol.message}')
    lo = np.array([b[0] if b[0] is not None else -np.inf for b in bounds])
    hi = np.array([b[1] if b[1] is not None else np.inf for b in bounds])
    primal_residual = max(float(np.abs(Aeq@sol.x-beq).max(initial=0)),
                          float(np.maximum(lo-sol.x, 0).max(initial=0)),
                          float(np.maximum(sol.x-hi, 0).max(initial=0)),
                          0 if Aub is None else float(np.maximum(Aub@sol.x-bub, 0).max(initial=0)))
    dual_obj = float(beq @ sol.eqlin.marginals)
    stationarity = c - Aeq.T @ sol.eqlin.marginals - sol.lower.marginals - sol.upper.marginals
    dual_sign = max(float(np.maximum(-sol.lower.marginals, 0).max(initial=0)),
                    float(np.maximum(sol.upper.marginals, 0).max(initial=0)))
    if Aub is not None:
        dual_obj += float(bub @ sol.ineqlin.marginals)
        stationarity -= Aub.T @ sol.ineqlin.marginals
        dual_sign = max(dual_sign, float(np.maximum(sol.ineqlin.marginals, 0).max(initial=0)))
    dual_obj += float(lo[np.isfinite(lo)] @ sol.lower.marginals[np.isfinite(lo)])
    dual_obj += float(hi[np.isfinite(hi)] @ sol.upper.marginals[np.isfinite(hi)])
    dual_gap = abs(float(sol.fun)-dual_obj)
    stationarity_residual = float(np.abs(stationarity).max(initial=0))
    assert max(primal_residual, dual_gap, stationarity_residual, dual_sign) < TOL, label
    AUDIT.append(dict(label=label, method=method, primal_residual=primal_residual,
                      dual_gap=dual_gap, stationarity_residual=stationarity_residual,
                      dual_sign_violation=dual_sign))
    return sol


def mean_bounds(d, proxy=None, rho=0.1, label=''):
    """Theorem 2: cellwise outcome means, plus 4K absolute-deviation variables."""
    K, px, g, r = d['K'], d['px'], d['g'], d['r']
    nv = 2*K if proxy is None else 6*K
    objective = np.r_[-px, px, np.zeros(nv-2*K)]
    Aeq = np.zeros((2, nv))
    Aeq[0, :K], Aeq[1, K:2*K] = g[0], g[1]
    beq = r[:, 1]
    rows, rhs = [], []
    if proxy is not None:
        for a in range(2):
            for y in range(2):
                tstart = 2*K+(2*a+y)*K
                for k in range(K):
                    # Implied q_{a,y,k} = slope*m_{a,k}+intercept.
                    slope = (1 if y else -1)*g[a, k]/r[a, y]
                    intercept = 0 if y else g[a, k]/r[a, y]
                    row = np.zeros(nv)
                    row[a*K+k], row[tstart+k] = slope, -1
                    rows.append(row)
                    rhs.append(proxy[a, y, k]-intercept)
                    row = np.zeros(nv)
                    row[a*K+k], row[tstart+k] = -slope, -1
                    rows.append(row)
                    rhs.append(intercept-proxy[a, y, k])
                row = np.zeros(nv)
                row[tstart:tstart+K] = 1
                rows.append(row)
                rhs.append(2*rho)
    bounds = [(0, 1)]*(2*K) + [(0, None)]*(nv-2*K)
    values, witnesses = [], []
    for sign, side in [(1, 'lower'), (-1, 'upper')]:
        sol = solve_checked(sign*objective, Aeq, beq, rows or None,
                            rhs or None, bounds, f'{label}_{side}')
        values.append(float(objective @ sol.x))
        witnesses.append(sol.x[:2*K].reshape(2, K))
    return np.array(values), np.array(witnesses)


def success_mass_bounds(d, proxy, rho, label=''):
    """Independent LP: u_{a,k}=P(X=k,Y=1|A=a); unnormalized TV rows.

    The y=1 budget is ||u-r1*qtilde1||_1 <= 2*rho*r1.
    The y=0 budget is ||g-u-r0*qtilde0||_1 <= 2*rho*r0.
    This uses a different variable scale and HiGHS interior-point solver.
    """
    K, g, r, px = d['K'], d['g'], d['r'], d['px']
    nv = 6*K
    c = np.r_[-px/g[0], px/g[1], np.zeros(4*K)]
    Aeq = np.zeros((2, nv))
    Aeq[0, :K] = Aeq[1, K:2*K] = 1
    rows, rhs = [], []
    for a in range(2):
        for y in range(2):
            tstart = 2*K+(2*a+y)*K
            for k in range(K):
                slope = 1 if y else -1
                intercept = 0 if y else g[a, k]
                center = r[a, y]*proxy[a, y, k]
                row = np.zeros(nv)
                row[a*K+k], row[tstart+k] = slope, -1
                rows.append(row)
                rhs.append(center-intercept)
                row = np.zeros(nv)
                row[a*K+k], row[tstart+k] = -slope, -1
                rows.append(row)
                rhs.append(intercept-center)
            row = np.zeros(nv)
            row[tstart:tstart+K] = 1
            rows.append(row)
            rhs.append(2*rho*r[a, y])
    bounds = [(0, float(v)) for v in g.ravel()] + [(0, None)]*(4*K)
    vals = []
    for sign, side in [(1, 'lower'), (-1, 'upper')]:
        sol = solve_checked(sign*c, Aeq, r[:, 1], rows, rhs, bounds,
                            f'{label}_{side}', method='highs-ipm')
        vals.append(float(c@sol.x))
    return np.array(vals)


def fan_sorting(d):
    """Discrete rearrangement/continuous-knapsack calculation, independent of LP."""
    arm_extrema = np.empty((2, 2))
    for a in range(2):
        weights = d['px']/d['g'][a]
        for side in range(2):
            order = np.argsort(weights)
            if side == 1:
                order = order[::-1]
            remaining = float(d['r'][a, 1])
            value = 0.0
            for k in order:
                take = min(remaining, float(d['g'][a, k]))
                value += weights[k]*take
                remaining -= take
                if remaining <= 1e-15:
                    break
            assert abs(remaining) < TOL
            arm_extrema[a, side] = value
    return np.array([arm_extrema[1, 0]-arm_extrema[0, 1],
                     arm_extrema[1, 1]-arm_extrema[0, 0]])


def run(output: Path):
    output.mkdir(parents=True, exist_ok=True)
    AUDIT.clear()
    rows, populations, witnesses = [], {}, {}
    max_fan_difference = max_formulation_difference = 0.0
    max_vacuous_difference = max_zero_radius_difference = 0.0
    max_truth_tv_error = max_witness_constraint_error = 0.0
    old_rounded = {2: [0.0475, 0.1125], 4: [0.0360, 0.1251], 16: [0.0329, 0.1351]}
    for K in (2, 4, 16):
        d = dgp(K)
        populations[str(K)] = {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in d.items()}
        fan, _ = mean_bounds(d, label=f'Fan_K{K}')
        sort_fan = fan_sorting(d)
        max_fan_difference = max(max_fan_difference, float(np.abs(fan-sort_fan).max()))
        np.testing.assert_allclose(fan, sort_fan, atol=TOL, rtol=0)
        zero, _ = mean_bounds(d, d['q'], rho=0, label=f'zero_K{K}')
        max_zero_radius_difference = max(max_zero_radius_difference, float(np.abs(zero-d['true_ate']).max()))
        np.testing.assert_allclose(zero, d['true_ate'], atol=TOL, rtol=0)
        for alpha in (0.0, 0.5, 1.0):
            rho = 0.1
            proxy = d['q'] + alpha*rho*d['v'][None, None, :]
            assert proxy.min() >= 0 and proxy.max() <= 1
            np.testing.assert_allclose(proxy.sum(axis=2), 1, atol=1e-14)
            true_tv = 0.5*np.abs(proxy-d['q']).sum(axis=2)
            max_truth_tv_error = max(max_truth_tv_error, float(np.abs(true_tv-alpha*rho).max()))
            np.testing.assert_allclose(true_tv, alpha*rho, atol=1e-14)
            ours, m_witness = mean_bounds(d, proxy, rho, label=f'ours_K{K}_alpha{alpha}')
            independent = success_mass_bounds(d, proxy, rho, label=f'mass_K{K}_alpha{alpha}')
            max_formulation_difference = max(max_formulation_difference, float(np.abs(ours-independent).max()))
            np.testing.assert_allclose(ours, independent, atol=TOL, rtol=0)
            unrestricted, _ = mean_bounds(d, proxy, rho=1, label=f'vacuous_K{K}_alpha{alpha}')
            max_vacuous_difference = max(max_vacuous_difference, float(np.abs(unrestricted-fan).max()))
            np.testing.assert_allclose(unrestricted, fan, atol=TOL, rtol=0)
            assert fan[0]-TOL <= ours[0] <= d['true_ate']+TOL
            assert d['true_ate']-TOL <= ours[1] <= fan[1]+TOL
            assert ours[0] <= ours[1]+TOL
            for mm in m_witness:
                qhat = np.stack([d['g']*(1-mm), d['g']*mm], axis=1)/d['r'][:, :, None]
                excess = max(float(np.maximum(0.5*np.abs(qhat-proxy).sum(axis=2)-rho, 0).max()),
                             float(np.abs((d['g']*mm).sum(axis=1)-d['r'][:, 1]).max()))
                max_witness_constraint_error = max(max_witness_constraint_error, excess)
                assert excess < TOL
            if alpha == 0:
                np.testing.assert_allclose(np.round(ours, 4), old_rounded[K], atol=1e-14, rtol=0)
            witnesses[f'K{K}_alpha{alpha}'] = dict(lower_m=m_witness[0].tolist(),
                upper_m=m_witness[1].tolist(), proxy=proxy.tolist(),
                sorted_fan_bounds=sort_fan.tolist(), alternative_bounds=independent.tolist())
            width = float(ours[1]-ours[0])
            if abs(width) < 1e-12:
                width = 0.0
            fan_width = float(fan[1]-fan[0])
            rows.append(dict(K=K, alpha=alpha, rho=rho, true_tv=alpha*rho,
                true_ate=d['true_ate'], fan_lower=fan[0], fan_upper=fan[1],
                fan_width=fan_width, proposed_lower=ours[0], proposed_upper=ours[1],
                proposed_width=width, reduction_pct=100*(1-width/fan_width),
                min_proxy_probability=float(proxy.min())))
    frame = pd.DataFrame(rows)
    frame.to_csv(output/'population_comparison.csv', index=False, float_format='%.16g')
    pd.DataFrame(AUDIT).to_csv(output/'solver_checks.csv', index=False)
    checks = dict(all_passed=True, number_of_settings=len(frame),
        number_of_lp_solves=len(AUDIT), max_fan_sorting_difference=max_fan_difference,
        max_equivalent_LP_difference=max_formulation_difference,
        max_rho1_vs_fan_difference=max_vacuous_difference,
        max_rho0_vs_truth_difference=max_zero_radius_difference,
        max_true_TV_error=max_truth_tv_error,
        max_witness_constraint_error=max_witness_constraint_error,
        max_primal_residual=max(r['primal_residual'] for r in AUDIT),
        max_duality_gap=max(r['dual_gap'] for r in AUDIT),
        max_stationarity_residual=max(r['stationarity_residual'] for r in AUDIT),
        min_proxy_probability=float(frame.min_proxy_probability.min()),
        alpha0_reproduces_draft_to_four_decimals=True,
        python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__, pandas=pd.__version__)
    for name, data in [('checks.json', checks), ('population_inputs.json', populations),
                       ('endpoint_witnesses.json', witnesses)]:
        (output/name).write_text(json.dumps(data, indent=2)+'\n')
    print(frame[['K', 'alpha', 'fan_lower', 'fan_upper', 'fan_width', 'proposed_lower', 'proposed_upper', 'proposed_width', 'reduction_pct']].to_string(index=False, float_format=lambda v: f'{v:.9f}'))
    print(json.dumps(checks, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'results')
    run(parser.parse_args().output)
