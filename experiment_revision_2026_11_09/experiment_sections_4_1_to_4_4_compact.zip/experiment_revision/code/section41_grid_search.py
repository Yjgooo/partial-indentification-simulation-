#!/usr/bin/env python3
"""Exhaustive Cartesian-grid comparison for Section 4.1 (binary confounder).

No branch-and-bound/cut, nonlinear local solver, adaptive search, or pruning.
Every point in the four-dimensional Cartesian grid is evaluated.
The auxiliary problem is also gridded after eliminating its two exact mixture
constraints. A separate continuous LP cross-checks the auxiliary endpoints.

Requirements: numpy, pandas, scipy, numba.
Example: python run_grid_study.py --nodes 33 65 129 257 --threads 4
The manuscript ZIP is neither read nor changed by this script.
"""
from __future__ import annotations
import argparse
import json
import platform
import time
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
import numba
from numba import njit, prange, set_num_threads
from scipy.optimize import linprog


@njit(parallel=True, cache=True)
def exhaustive_pairs(g0, mn0, d0, g1, mn1, d1, pa1, r0, r1):
    """Enumerate EVERY pair of arm states: exactly M^4 points without auxiliary."""
    count0, count1 = len(g0), len(g1)
    mins, maxs = np.empty(count0), np.empty(count0)
    imin, imax = np.empty(count0, dtype=np.int64), np.empty(count0, dtype=np.int64)
    const = pa1*r1 - (1-pa1)*r0
    for i in prange(count0):
        lower, upper = np.inf, -np.inf
        il, iu = -1, -1
        c = const-pa1*mn0[i]
        b = (1-pa1)*g0[i]
        e = -pa1*d0[i]
        for j in range(count1):
            value = c+(1-pa1)*mn1[j]+b*d1[j]+e*g1[j]
            if value < lower:
                lower, il = value, j
            if value > upper:
                upper, iu = value, j
        mins[i], maxs[i], imin[i], imax[i] = lower, upper, il, iu
    low_i, high_i = np.argmin(mins), np.argmax(maxs)
    return mins[low_i], maxs[high_i], low_i, imin[low_i], high_i, imax[high_i]


def population():
    """Existing base DGP, restricted to K=2; q[a,y,k] is indexed by increasing X."""
    x = np.array([-1., 1.])
    px = np.array([.5, .5])
    e = .5+.1*x
    m = .35+.15*x[None, :]+.08*np.arange(2)[:, None]
    joint_ax = px[None, :]*np.stack((1-e, e))
    pa = joint_ax.sum(axis=1)
    g = joint_ax/pa[:, None]
    r1 = (g*m).sum(axis=1)
    r = np.stack((1-r1, r1), axis=1)
    q = np.stack((g*(1-m), g*m), axis=1)/r[:, :, None]
    return dict(x=x, px=px, e=e, m=m, pa=pa, g=g, r=r, q=q,
                true_ate=float(px@(m[1]-m[0])))


def coordinates_to_law(s, pop):
    """s[a,y]=candidate P(X=+1|A=a,Y=y); recover unknown covariate margins."""
    s = np.asarray(s)
    q = np.stack((1-s, s), axis=-1)
    g = np.sum(pop['r'][:, :, None]*q, axis=1)
    assert np.all(g>0)
    m = pop['r'][:, 1, None]*q[:, 1, :]/g
    px = pop['pa']@g
    ate = float(px@(m[1]-m[0]))
    return dict(q=q, g=g, m=m, px=px, ate=ate)


def arm_states(s0, s1, r):
    g = (1-r)*s0+r*s1
    if not (np.all(g>0) and np.all(g<1)):
        raise ValueError('The selected design must keep every grid denominator positive.')
    mn = r*(1-s1)/(1-g)
    mp = r*s1/g
    return g, mn, mp-mn


def noaux_grid(pop, proxy, rho, nodes):
    lower = np.maximum(proxy[:, :, 1]-rho, 0.)
    upper = np.minimum(proxy[:, :, 1]+rho, 1.)
    params, states = [], []
    for a in (0, 1):
        a0, a1 = np.meshgrid(np.linspace(lower[a, 0], upper[a, 0], nodes),
                             np.linspace(lower[a, 1], upper[a, 1], nodes), indexing='ij')
        params.append(np.column_stack((a0.ravel(), a1.ravel())))
        states.append(arm_states(a0.ravel(), a1.ravel(), pop['r'][a, 1]))
    result = exhaustive_pairs(*states[0], *states[1], pop['pa'][1], *pop['r'][:, 1])
    witnesses = [np.stack((params[0][result[2]], params[1][result[3]])),
                 np.stack((params[0][result[4]], params[1][result[5]]))]
    return np.array(result[:2]), witnesses, lower, upper


def auxiliary_grid(pop, proxy, rho, nodes):
    """Use known g to eliminate s[a,0], then enumerate the full 2-D feasible grid."""
    lower = np.maximum(proxy[:, :, 1]-rho, 0.)
    upper = np.minimum(proxy[:, :, 1]+rho, 1.)
    params, states = [], []
    for a in (0, 1):
        r, g = pop['r'][a, 1], pop['g'][a, 1]
        lo = max(lower[a, 1], (g-(1-r)*upper[a, 0])/r)
        hi = min(upper[a, 1], (g-(1-r)*lower[a, 0])/r)
        if lo>hi+1e-12:
            raise ValueError('Population auxiliary problem unexpectedly infeasible.')
        s1 = np.array([(hi+lo)/2]) if hi-lo<1e-12 else np.linspace(lo, hi, nodes)
        s0 = (g-r*s1)/(1-r)
        params.append(np.column_stack((s0, s1)))
        states.append(arm_states(s0, s1, r))
    result = exhaustive_pairs(*states[0], *states[1], pop['pa'][1], *pop['r'][:, 1])
    witnesses = [np.stack((params[0][result[2]], params[1][result[3]])),
                 np.stack((params[0][result[4]], params[1][result[5]]))]
    return np.array(result[:2]), witnesses


def auxiliary_lp(pop, proxy, rho):
    """Independent LP in outcome means; all TV constraints explicitly linearized."""
    K, nv = 2, 12
    c = np.r_[-pop['px'], pop['px'], np.zeros(8)]
    Aeq = np.zeros((2, nv))
    Aeq[0, :2], Aeq[1, 2:4] = pop['g'][0], pop['g'][1]
    rows, rhs = [], []
    for a in (0, 1):
        for y in (0, 1):
            t = 4+(2*a+y)*K
            for k in range(K):
                slope = (1 if y else -1)*pop['g'][a, k]/pop['r'][a, y]
                intercept = 0. if y else pop['g'][a, k]/pop['r'][a, y]
                for sign in (1, -1):
                    row = np.zeros(nv)
                    row[a*K+k], row[t+k] = sign*slope, -1.
                    rows.append(row)
                    rhs.append(sign*(proxy[a, y, k]-intercept))
            row = np.zeros(nv)
            row[t:t+K] = 1
            rows.append(row)
            rhs.append(2*rho)
    out = []
    for sign in (1, -1):
        sol = linprog(sign*c, A_ub=np.array(rows), b_ub=rhs,
                      A_eq=Aeq, b_eq=pop['r'][:, 1],
                      bounds=[(0., 1.)]*4+[(0., None)]*8,
                      method='highs-ds', options={'primal_feasibility_tolerance':1e-9,
                                                'dual_feasibility_tolerance':1e-9})
        if not sol.success:
            raise RuntimeError(sol.message)
        out.append(float(c@sol.x))
    return np.array(out)


def direct_bruteforce_test(pop, proxy, rho):
    """Independent vectorized evaluation of the ORIGINAL g-formula on a small grid."""
    nodes = 7
    low = np.maximum(proxy[:, :, 1]-rho, 0.)
    high = np.minimum(proxy[:, :, 1]+rho, 1.)
    mesh = np.meshgrid(*(np.linspace(l, h, nodes) for l, h in zip(low.ravel(),high.ravel())), indexing='ij')
    s = np.column_stack([v.ravel() for v in mesh]).reshape(-1, 2, 2)
    q = np.stack((1-s, s), axis=-1)
    g = np.sum(pop['r'][None, :, :, None]*q, axis=2)
    m = pop['r'][None, :, 1, None]*q[:, :, 1, :]/g
    px = np.sum(pop['pa'][None, :, None]*g, axis=1)
    values = np.sum(px*(m[:, 1, :]-m[:, 0, :]), axis=1)
    oracle = np.array([values.min(), values.max()])
    checked, *_ = noaux_grid(pop, proxy, rho, nodes)
    err = float(np.max(np.abs(oracle-checked)))
    assert err<1e-12
    return err


def serializable(obj):
    if isinstance(obj, dict): return {k:serializable(v) for k,v in obj.items()}
    if isinstance(obj, (list,tuple)): return [serializable(v) for v in obj]
    if isinstance(obj,np.ndarray): return obj.tolist()
    if isinstance(obj,np.generic): return obj.item()
    return obj


def run(args):
    args.output.mkdir(parents=True, exist_ok=True)
    set_num_threads(args.threads)
    pop = population()
    np.testing.assert_allclose(pop['g'][:, 1], [.4,.6], atol=1e-14)
    np.testing.assert_allclose(pop['r'][:, 1], [.32,.46], atol=1e-14)
    rows, summaries, witness_out, checks = [], [], {}, []
    for alpha in args.alphas:
        rho=.1
        proxy=pop['q']+alpha*rho*np.array([1., -1.])[None,None,:]
        assert proxy.min()>0 and np.max(np.abs(proxy.sum(axis=2)-1))<1e-14
        np.testing.assert_allclose(.5*np.abs(proxy-pop['q']).sum(axis=2),alpha*rho,atol=1e-14)
        test_error = direct_bruteforce_test(pop,proxy,rho)
        aux, aux_witness=auxiliary_grid(pop,proxy,rho,max(args.nodes))
        aux_lp=auxiliary_lp(pop,proxy,rho)
        np.testing.assert_allclose(aux,aux_lp,atol=1e-12,rtol=0)
        last=None
        for nodes in args.nodes:
            start=time.perf_counter()
            vals, witnesses, lower, upper=noaux_grid(pop,proxy,rho,nodes)
            elapsed=time.perf_counter()-start
            step=float(np.max((upper-lower)/(nodes-1)))
            current=dict(K=2,alpha=alpha,rho=rho,nodes_per_coordinate=nodes,
                         points_evaluated=nodes**4,max_grid_spacing=step,
                         noaux_lower=vals[0],noaux_upper=vals[1],
                         noaux_width=vals[1]-vals[0],runtime_seconds=elapsed,
                         lower_change=np.nan if last is None else vals[0]-last[0],
                         upper_change=np.nan if last is None else vals[1]-last[1])
            rows.append(current)
            if last is not None:
                assert vals[0]<=last[0]+1e-12 and vals[1]>=last[1]-1e-12
            last=vals
            print(json.dumps(serializable(current)),flush=True)
        checks_alpha = dict(alpha=alpha,small_grid_vs_direct_formula_error=test_error,
                            auxiliary_grid_vs_LP_error=float(np.max(np.abs(aux-aux_lp))))
        for group, vs, ws in [('noaux',vals,witnesses),('aux',aux,aux_witness)]:
            for side,value,s in zip(('lower','upper'),vs,ws):
                law=coordinates_to_law(s,pop)
                true_tv=.5*np.abs(law['q']-proxy).sum(axis=2)
                err=max(float(np.maximum(true_tv-rho,0).max()),
                        float(np.abs(law['q'].sum(axis=2)-1).max()),abs(value-law['ate']))
                if group=='aux': err=max(err,float(np.abs(law['g']-pop['g']).max()))
                assert err<1e-12
                checks_alpha[f'{group}_{side}_max_residual']=err
                witness_out[f'alpha{alpha}_{group}_{side}']=dict(s=s,**law,tv=true_tv,proxy=proxy)
        assert vals[0]<=aux[0]+1e-12 and aux[1]<=vals[1]+1e-12
        assert aux[0]<=pop['true_ate']+1e-12 and pop['true_ate']<=aux[1]+1e-12
        width=float(aux[1]-aux[0])
        if abs(width)<1e-12:width=0.
        summaries.append(dict(K=2,alpha=alpha,rho=rho,actual_tv=alpha*rho,true_ate=pop['true_ate'],
                              auxiliary_lower=aux[0],auxiliary_upper=aux[1],auxiliary_width=width,
                              noaux_grid_lower=vals[0],noaux_grid_upper=vals[1],
                              noaux_grid_width=vals[1]-vals[0],
                              width_reduction_lower_bound_pct=100*(1-width/(vals[1]-vals[0])),
                              nodes_per_coordinate=max(args.nodes),grid_points=max(args.nodes)**4))
        checks.append(checks_alpha)
    pd.DataFrame(rows).to_csv(args.output/'grid_refinement.csv',index=False,float_format='%.16g')
    pd.DataFrame(summaries).to_csv(args.output/'comparison_table.csv',index=False,float_format='%.16g')
    metadata=dict(design='K=2; existing standardized binary DGP; unified half-support proxy shift',
                  rho=.1,alphas=args.alphas,nodes=args.nodes,threads=args.threads,
                  search='Full Cartesian-product enumeration; no pruning or nonlinear optimization',
                  raw_noaux_grid_is_inner_approximation=True,
                  largest_grid_denominator_min=float(min((np.sum(pop['r']*lower,axis=1)).min(),
                                                        (1-np.sum(pop['r']*upper,axis=1)).min())),
                  python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
                  numba=numba.__version__,population=pop,checks=checks)
    for name,data in [('checks_and_inputs.json',metadata),('endpoint_witnesses.json',witness_out)]:
        (args.output/name).write_text(json.dumps(serializable(data),indent=2)+'\n')
    print('\nCOMPLETED TABLE\n'+pd.DataFrame(summaries).to_string(index=False),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=Path(__file__).parent/'results')
    p.add_argument('--nodes',type=int,nargs='+',default=[33,65,129,257])
    p.add_argument('--alphas',type=float,nargs='+',default=[0.2,0.5,0.8])
    p.add_argument('--threads',type=int,default=4)
    args=p.parse_args()
    if any(m<2 for m in args.nodes) or args.nodes!=sorted(set(args.nodes)):
        p.error('Grid sizes must be distinct increasing integers >=2.')
    if any(not 0<=a<=1 for a in args.alphas):p.error('alpha must lie in [0,1].')
    run(args)
