This is a compact version of the revised experiment-section package.
It includes the complete Section 4.1–4.4 LaTeX source, analysis code,
summary data, validation checks, PDF preview, and vector PDF figures.
The 4.48 MB raw replication archive and redundant PNG plots are omitted
only to make the download smaller. Code for reproducing simulations is included.
This is a replacement experiment-section package, NOT the entire manuscript ZIP.
