#!/usr/bin/env python3
"""Build Sections 4.3--4.4 from saved simulations and fresh population LPs.

Reuses, never reruns or changes, the original 54,000 Section 4.2 replications.
Recomputes Fan and proxy-TV population bounds for K=2,4,16, alpha=.2,.5,.8.
"""
from __future__ import annotations
import argparse
import json
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog, OptimizeWarning
import population_bounds as pb

warnings.filterwarnings('ignore', category=OptimizeWarning,
                        message='Unrecognized options detected.*')
KS = (2, 4, 16)
ALPHAS = (0.2, 0.5, 0.8)
SIZES = (250, 1000, 4000, 16000)
RHO = 0.10


def feasible_success_mass(r: np.ndarray, g: np.ndarray,
                          proxy: np.ndarray) -> tuple[bool, str, bool, str]:
    """Independent feasibility check in u=P(X,Y=1|A), not mean variables.

    Individual zero g cells cause no division and are kept, not smoothed.
    Uses HiGHS interior point rather than the original dual-simplex solve.
    """
    K = g.shape[1]
    nv = 6*K
    eq = np.zeros((2, nv))
    eq[0, :K] = eq[1, K:2*K] = 1
    rows, rhs = [], []
    for a in range(2):
        for y in range(2):
            start = 2*K+(2*a+y)*K
            for k in range(K):
                slope = 1 if y else -1
                offset = 0 if y else g[a,k]
                center = r[a,y]*proxy[a,y,k]
                row = np.zeros(nv)
                row[a*K+k], row[start+k] = slope, -1
                rows.append(row); rhs.append(center-offset)
                row = np.zeros(nv)
                row[a*K+k], row[start+k] = -slope, -1
                rows.append(row); rhs.append(offset-center)
            row = np.zeros(nv); row[start:start+K] = 1
            rows.append(row); rhs.append(2*RHO*r[a,y])
    attempts = []
    for method, presolve in [('highs-ipm', True), ('highs-ipm', False),
                              ('highs-ds', False)]:
        sol = linprog(np.zeros(nv), A_ub=np.asarray(rows), b_ub=np.asarray(rhs),
                      A_eq=eq, b_eq=r[:,1],
                      bounds=[(0,float(v)) for v in g.ravel()]+[(0,None)]*(4*K),
                      method=method,
                      options={'primal_feasibility_tolerance':1e-9,
                               'dual_feasibility_tolerance':1e-9,
                               'ipm_optimality_tolerance':1e-10,
                               'threads':1, 'presolve':presolve})
        attempts.append(f'{method};presolve={presolve};status={sol.status}')
        if sol.success or sol.status == 2:
            return bool(sol.success), method, presolve, '|'.join(attempts)
    raise RuntimeError('Unresolved independent feasibility solve: '+sol.message)



def build(root: Path) -> None:
    out = root/'results'
    reps = pd.read_csv(out/'replications.csv.gz')
    summary = pd.read_csv(out/'accuracy_summary.csv')
    assert len(reps) == 54000 and reps.success.all() and reps.ordered.all()
    assert not reps[['lower_hat','upper_hat']].isna().any().any()
    assert not reps.duplicated(['K','alpha','n','replication']).any()
    grouped = reps.groupby(['K','alpha','n','N'], sort=True)
    feas = grouped.agg(repetitions=('replication','size'),
                       feasible_count=('raw_feasible','sum'),
                       penalized_success_count=('success','sum'),
                       ordered_count=('ordered','sum')).reset_index()
    assert len(feas) == 36 and feas.repetitions.eq(1500).all()
    feas['infeasible_count'] = feas.repetitions-feas.feasible_count
    feas['feasibility_rate'] = feas.feasible_count/feas.repetitions
    feas['feasibility_percent'] = 100*feas.feasibility_rate
    feas['binomial_mcse_percent'] = 100*np.sqrt(feas.feasibility_rate*(1-feas.feasibility_rate)/feas.repetitions)
    check = feas.merge(summary[['K','alpha','n','raw_feasibility_rate']], on=['K','alpha','n'], validate='1:1')
    max_summary_error = float(np.abs(check.feasibility_rate-check.raw_feasibility_rate).max())
    assert max_summary_error < 1e-14
    feas.to_csv(out/'feasibility_summary.csv',index=False)
    feas.pivot(index=['alpha','n'], columns='K', values='feasibility_percent').to_csv(out/'feasibility_percentages.csv')

    # Reconstruct selected samples with the exact original RNG procedure, then
    # classify them with an independently parameterized feasibility LP.
    seed = int(json.loads((out/'metadata.json').read_text())['seed'])
    indep = []
    for (K,alpha,n,N), cell in grouped:
        d = pb.dgp(int(K))
        proxy0 = d['q']+alpha*RHO*d['v'][None,None,:]
        mainlaw = d['pa'][:,None,None]*d['r'][:,:,None]*proxy0
        auxlaw = d['pa'][:,None]*d['g']
        # First three plus at least one feasible and one infeasible when present.
        selected = {int(x) for x in cell.replication.iloc[:3]}
        for flag in (True,False):
            sub=cell[cell.raw_feasible.eq(flag)]
            if len(sub): selected.add(int(sub.replication.iloc[0]))
        for rep in sorted(selected):
            ss=np.random.SeedSequence([seed,int(K),int(round(alpha*100)),int(n),rep])
            sm,sa=ss.spawn(2)
            main=np.random.default_rng(sm).multinomial(int(n),mainlaw.ravel()).reshape(2,2,int(K))
            aux=np.random.default_rng(sa).multinomial(int(N),auxlaw.ravel()).reshape(2,int(K))
            ay=main.sum(axis=2)
            r=ay/ay.sum(axis=1,keepdims=True)
            g=aux/aux.sum(axis=1,keepdims=True)
            proxy=main/ay[:,:,None]
            result,method,presolve,history=feasible_success_mass(r,g,proxy)
            saved=bool(cell.loc[cell.replication.eq(rep),'raw_feasible'].iloc[0])
            assert result == saved, (K,alpha,n,rep,result,saved)
            indep.append(dict(K=K,alpha=alpha,n=n,replication=rep,
                              saved_feasible=saved,independent_feasible=result,
                              zero_aux_cells=int((aux==0).sum()),
                              final_method=method,presolve=presolve,history=history))
    pd.DataFrame(indep).to_csv(out/'feasibility_independent_checks.csv',index=False)

    pb.AUDIT.clear()
    rows, witnesses, inputs = [], {}, {}
    err = dict(max_fan_rearrangement_error=0.,max_success_mass_error=0.,
               max_vacuous_radius_error=0.,max_zero_radius_error=0.,
               max_prior_oracle_error=0.,max_tv_witness_excess=0.,
               max_actual_tv_error=0.)
    for K in KS:
        d=pb.dgp(K)
        fan,_=pb.mean_bounds(d,label=f'Fan_K{K}')
        independently_sorted=pb.fan_sorting(d)
        err['max_fan_rearrangement_error']=max(err['max_fan_rearrangement_error'],float(np.max(np.abs(fan-independently_sorted))))
        zero,_=pb.mean_bounds(d,d['q'],rho=0,label=f'zero_K{K}')
        err['max_zero_radius_error']=max(err['max_zero_radius_error'],float(np.max(np.abs(zero-d['true_ate']))))
        inputs[str(K)]={k:v.tolist() if isinstance(v,np.ndarray) else v for k,v in d.items()}
        for alpha in ALPHAS:
            proxy=d['q']+alpha*RHO*d['v'][None,None,:]
            assert proxy.min()>0 and proxy.max()<1
            np.testing.assert_allclose(proxy.sum(axis=2),1,atol=1e-14)
            tv=.5*np.abs(proxy-d['q']).sum(axis=2)
            err['max_actual_tv_error']=max(err['max_actual_tv_error'],float(np.max(np.abs(tv-alpha*RHO))))
            ours, means=pb.mean_bounds(d,proxy,RHO,label=f'proposed_K{K}_a{alpha}')
            alternative=pb.success_mass_bounds(d,proxy,RHO,label=f'independent_K{K}_a{alpha}')
            err['max_success_mass_error']=max(err['max_success_mass_error'],float(np.max(np.abs(ours-alternative))))
            vacuous,_=pb.mean_bounds(d,proxy,1,label=f'vacuous_K{K}_a{alpha}')
            err['max_vacuous_radius_error']=max(err['max_vacuous_radius_error'],float(np.max(np.abs(vacuous-fan))))
            old=summary[(summary.K==K)&(summary.alpha==alpha)].iloc[0]
            err['max_prior_oracle_error']=max(err['max_prior_oracle_error'],float(np.max(np.abs(ours-[old.lower_oracle,old.upper_oracle]))))
            assert fan[0]-1e-10<=ours[0]<=d['true_ate']+1e-10<=ours[1]+1e-10<=fan[1]+1e-10
            for m in means:
                q=np.stack([d['g']*(1-m),d['g']*m],axis=1)/d['r'][:,:,None]
                excess=float(np.maximum(.5*np.abs(q-proxy).sum(axis=2)-RHO,0).max())
                err['max_tv_witness_excess']=max(err['max_tv_witness_excess'],excess)
                np.testing.assert_allclose((d['g']*m).sum(axis=1),d['r'][:,1],atol=1e-10)
            width=float(ours[1]-ours[0]); fan_width=float(fan[1]-fan[0])
            rows.append(dict(K=K,alpha=alpha,rho=RHO,actual_tv=alpha*RHO,
                true_ate=d['true_ate'],fan_lower=fan[0],fan_upper=fan[1],fan_width=fan_width,
                proposed_lower=ours[0],proposed_upper=ours[1],proposed_width=width,
                reduction_percent=100*(1-width/fan_width)))
            witnesses[f'K{K}_alpha{alpha}']=dict(lower_means=means[0].tolist(),upper_means=means[1].tolist(),proxy=proxy.tolist())
    assert max(err.values())<1e-10, err
    frame=pd.DataFrame(rows)
    frame.to_csv(out/'fan_comparison.csv',index=False,float_format='%.16g')
    pd.DataFrame(pb.AUDIT).to_csv(out/'fan_lp_solver_checks.csv',index=False)
    for name,data in [('fan_endpoint_witnesses',witnesses),('fan_population_inputs',inputs)]:
        (out/f'{name}.json').write_text(json.dumps(data,indent=2)+'\n')
    checks=dict(all_passed=True,total_existing_replications=len(reps),
                repetitions_per_setting=1500,number_of_feasibility_settings=len(feas),
                independent_feasibility_checks=len(indep),
                total_direct_lp_infeasible=int((~reps.raw_feasible).sum()),
                max_saved_feasibility_difference=max_summary_error,
                all_penalized_successful=bool(reps.success.all()),
                all_penalized_ordered=bool(reps.ordered.all()),
                fan_comparison_settings=len(frame),**err)
    (out/'sections43_44_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    table=[r'\begin{table}[htbp]',r'\centering',
           r'\caption{Population ATE bounds using auxiliary data, with and without proxy information.}',
           r'\label{tab:fan-comparison}',r'\small',r'\setlength{\tabcolsep}{4pt}',
           r'\begin{tabular}{@{}cc cc cc r@{}}',r'\toprule',
           r'& & \multicolumn{2}{c}{Fan et al.\ (2014)} & \multicolumn{2}{c}{Proposed} & \\',
           r'\cmidrule(lr){3-4}\cmidrule(lr){5-6}',
           r'$K$ & $\alpha$ & Interval & Width & Interval & Width & Reduction \\',r'\midrule']
    for i,row in enumerate(frame.itertuples(index=False)):
        if i and i%3==0:table.append(r'\addlinespace[4pt]')
        table.append(f'{row.K} & {row.alpha:.1f} & $[{row.fan_lower:.4f},\\,{row.fan_upper:.4f}]$ & {row.fan_width:.4f} & $[{row.proposed_lower:.4f},\\,{row.proposed_upper:.4f}]$ & {row.proposed_width:.4f} & {row.reduction_percent:.1f}\\% '+r'\\')
    table.extend([r'\bottomrule',r'\end{tabular}',r'\par\smallskip',r'\begin{minipage}{\linewidth}',r'\footnotesize',
        r'The assumed TV radius is $\rho=0.10$ and the true ATE is $0.08$.',
        r'Reduction is $100(1-W_{\mathrm{proposed}}/W_{\mathrm{Fan}})\%$, calculated before rounding.',
        r'\end{minipage}',r'\end{table}'])
    (root/'manuscript/table_section44.tex').write_text('\n'.join(table)+'\n')
    print(frame.to_string(index=False,float_format=lambda x:f'{x:.6f}'))
    print('\nCHECKS\n'+json.dumps(checks,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    build(parser.parse_args().root)
